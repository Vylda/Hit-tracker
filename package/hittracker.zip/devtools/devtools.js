
/**
Create a panel, and add listeners for panel show/hide events.
*/
browser.devtools.panels.create(
	"Hit tracker",
	"/icons/logs-48.png",
	"/devtools/panel/panel.html"
);
